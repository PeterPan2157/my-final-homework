/**
 * Created by PeterPan on 2016/4/22.
 */
function uploadWork(){
    alert("你点干嘛");
}