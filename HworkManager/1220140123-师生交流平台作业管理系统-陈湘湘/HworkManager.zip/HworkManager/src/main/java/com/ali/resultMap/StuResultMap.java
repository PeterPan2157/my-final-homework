package com.ali.resultMap;

public class StuResultMap {
	private Integer stuid;

	private Integer claid;

	public Integer getClaid() {
		return claid;
	}

	public void setClaid(Integer claid) {
		this.claid = claid;
	}

	private String claname;

	private String stuname;

	private String stupwd;

	private String stusex;

	private Integer stuage;

	private String stutel;
	
	private String stuemail;

	private String stustatus;

	public Integer getStuid() {
		return stuid;
	}

	public void setStuid(Integer stuid) {
		this.stuid = stuid;
	}

	public String getClaname() {
		return claname;
	}

	public void setClaname(String claname) {
		this.claname = claname;
	}

	public String getStuname() {
		return stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getStupwd() {
		return stupwd;
	}

	public void setStupwd(String stupwd) {
		this.stupwd = stupwd;
	}

	public String getStusex() {
		return stusex;
	}

	public void setStusex(String stusex) {
		this.stusex = stusex;
	}

	public Integer getStuage() {
		return stuage;
	}

	public void setStuage(Integer stuage) {
		this.stuage = stuage;
	}

	public String getStutel() {
		return stutel;
	}

	public void setStutel(String stutel) {
		this.stutel = stutel;
	}

	public String getStuemail() {
		return stuemail;
	}

	public void setStuemail(String stuemail) {
		this.stuemail = stuemail;
	}

	public String getStustatus() {
		return stustatus;
	}

	public void setStustatus(String stustatus) {
		this.stustatus = stustatus;
	}


}