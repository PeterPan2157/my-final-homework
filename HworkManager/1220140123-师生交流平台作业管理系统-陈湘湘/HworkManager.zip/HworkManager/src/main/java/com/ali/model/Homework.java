package com.ali.model;

public class Homework {
    private Integer hwid;

    private Integer stuid;

    private Integer hwpid;

    private String hwpath;

    private String hwstatus;

    public Integer getHwid() {
        return hwid;
    }

    public void setHwid(Integer hwid) {
        this.hwid = hwid;
    }

    public Integer getStuid() {
        return stuid;
    }

    public void setStuid(Integer stuid) {
        this.stuid = stuid;
    }

    public Integer getHwpid() {
        return hwpid;
    }

    public void setHwpid(Integer hwpid) {
        this.hwpid = hwpid;
    }

    public String getHwpath() {
        return hwpath;
    }

    public void setHwpath(String hwpath) {
        this.hwpath = hwpath;
    }

    public String getHwstatus() {
        return hwstatus;
    }

    public void setHwstatus(String hwstatus) {
        this.hwstatus = hwstatus;
    }

	@Override
	public String toString() {
		return "Homework [hwid=" + hwid + ", stuid=" + stuid + ", hwpid="
				+ hwpid + ", hwpath=" + hwpath + ", hwstatus=" + hwstatus + "]";
	}
    
}