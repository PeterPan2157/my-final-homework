package com.ali.service;

import java.util.List;

import com.ali.model.Courses;
import com.ali.model.Students;
import com.ali.model.TeachClaCou;
import com.ali.resultMap.TccResultMap;

/**
 * tcc（教师-班级-课程）操作
 * 
 * @author PeterPan
 * 
 */
// TODO：这个模块的操作只提供给管理员
public interface TccInfoService {
	/**
	 * 新增tcc记录，在这里，只提供完整插入
	 * 
	 * @param teachClaCou
	 * @return
	 */
	public int insertTccInfo(TeachClaCou teachClaCou);

	/**
	 * 通过tcc编号删除相应记录
	 * 
	 * @param tccId
	 * @return
	 */
	public int delTccInfoByTccId(int tccId);

	/**
	 * 更新tcc信息，参数对象中包含逐渐tccId
	 * 
	 * @param teachClaCou
	 * @return
	 */
	public int updateTccInfo(TeachClaCou teachClaCou);

	public int updateByPrimaryKeySelective(TeachClaCou teachClaCou);

	/**
	 * 查找tcc记录，通过tccId
	 * 
	 * @param tccId
	 * @return
	 */
	public TeachClaCou selectTccByPrimaryKey(int tccId);

	public List<TeachClaCou> selectTccByClaId(int claId, int StartNo,
			int pageSize);

	public List<TeachClaCou> selectTccByCouId(int couId, int StartNo,
			int pageSize);

	public List<TeachClaCou> selectTccByTeachId(int teachId, int StartNo,
			int pageSize);

	// TODO：下面这几个方法都是获取新创建的resultMap对象的方法，需要另外写sql语句和映射方法

	public TccResultMap selectTccRMByPrimaryKey(int tccId, int StartNo,
			int pageSize);

	public List<TccResultMap> selectTccRMByClaId(int claId, int StartNo,
			int pageSize);

	public List<TccResultMap> selectTccRMByCouId(int couId, int StartNo,
			int pageSize);

	public List<TccResultMap> selectTccRMByTeachId(int teachId, int StartNo,
			int pageSize);

	public List<TccResultMap> selectAllTccRM(int StartNo, int pageSize);

	public int countAllTccRM();

	public List<Courses> selectCouByClaId(Students students);
}
