package com.ali.service.impl;

import java.util.List;

import com.ali.mapper.HomeworkMapper;
import com.ali.mapper.HworkPublishMapper;
import com.ali.model.Homework;
import com.ali.model.HworkPublish;
import com.ali.model.Students;
import com.ali.resultMap.StuHomeworkResultMap;
import com.ali.service.HomeworkService;

public class HomeworkServiceImpl implements HomeworkService {

	private HomeworkMapper homeworkMapper;
	private HworkPublishMapper hworkPublishMapper;

	public HworkPublishMapper getHworkPublishMapper() {
		return hworkPublishMapper;
	}

	public void setHworkPublishMapper(HworkPublishMapper hworkPublishMapper) {
		this.hworkPublishMapper = hworkPublishMapper;
	}

	public HomeworkMapper getHomeworkMapper() {
		return homeworkMapper;
	}

	public void setHomeworkMapper(HomeworkMapper homeworkMapper) {
		this.homeworkMapper = homeworkMapper;
	}

	public int deleteByPrimaryKey(Integer hwid) {
		return homeworkMapper.deleteByPrimaryKey(hwid);
	}

	public int insert(Homework record) {
		return homeworkMapper.insert(record);
	}

	public int insertSelective(Homework record) {
		return homeworkMapper.insertSelective(record);
	}

	public Homework selectByPrimaryKey(Integer hwid) {
		return homeworkMapper.selectByPrimaryKey(hwid);
	}

	public int updateByPrimaryKeySelective(Homework record) {
		return homeworkMapper.updateByPrimaryKeySelective(record);
	}

	public int updateByPrimaryKey(Homework record) {
		return homeworkMapper.updateByPrimaryKey(record);
	}

	public List<Homework> selectStuHomeworkByStuId(Integer stuId) {
		return homeworkMapper.selectStuHomeworkByStuId(stuId);
	}

	public List<HworkPublish> selectHworkPublishByClaId(Integer claId) {
		return hworkPublishMapper.selectHworkPublishByClaId(claId);
	}

	public List<Homework> selectStuHomeworkByCouId(Integer stuId, Integer couId) {
		return homeworkMapper.selectStuHomeworkByCouId(stuId, couId);
	}

	public List<HworkPublish> selectHworkPublishByCouId(Integer claId,
			Integer couId) {
		return hworkPublishMapper.selectHworkPublishByCouId(claId, couId);
	}

	public int countHomeworkByStuId(Integer stuId) {
		return homeworkMapper.countHomeworkByStuId(stuId);
	}

	public int countHworkPublishByClaId(Integer claId) {
		return hworkPublishMapper.countHworkPublishByClaId(claId);
	}

	public List<StuHomeworkResultMap> selectAllHomeworkByStuId(Integer stuId) {
		return homeworkMapper.selectAllHomeworkByStuId(stuId);
	}

	public int updateHwPath(Homework record) {
		return homeworkMapper.updateHwPath(record);
	}

	public void updateHomework(Students students) {
		// 对比班级作业数与学生作业数
		if (countHomeworkByStuId(students.getStuid()) != countHworkPublishByClaId(students
				.getClaid())) {
			// 不相等时，取出学生所有作业，班级所有作业进行比较
			List<Homework> stulist = selectStuHomeworkByStuId(students
					.getStuid());

			List<HworkPublish> clalist = selectHworkPublishByClaId(students
					.getClaid());
			// System.out.println(stulist);
			// System.out.println(clalist);
			// /循环取出班级作业记录中的作业编号，并于学生记录进行比较
			Homework stu;
			HworkPublish cla;
			// System.out.println(clalist.size());
			// System.out.println(stulist.size());

			int j = 0;
			for (int i = 0; i < clalist.size(); i++) {
				cla = clalist.get(i);
				// System.out.println("cla.getHwpid()" + cla.getHwpid());
				if (stulist.size() > 0) {
					if (j < stulist.size()) {
						for (; j < stulist.size();) {
							stu = stulist.get(j);

							// System.out.println("stu.getHwpid()"
							// + stu.getHwpid());

							// System.out.println("i=" + i);
							// System.out.println("j=" + j);

							if (cla.getHwpid() == stu.getHwpid()) {
								// //存在，跳过
								// System.out.println("break;");
								j++;
								break;
							}
						}
					} else {
						Homework hw = new Homework();
						hw.setStuid(students.getStuid());
						hw.setHwpid(cla.getHwpid());
						// System.out.println(hw);
						homeworkMapper.insertSelective(hw);
					}

				} else {
					// 为了防止出现学生记录为0的情况，需要做出判断
					Homework hw = new Homework();
					hw.setStuid(students.getStuid());
					hw.setHwpid(cla.getHwpid());
					homeworkMapper.insertSelective(hw);
				}
			}
		}
	}
}
