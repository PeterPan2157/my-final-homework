package com.ali.action;

import net.sf.json.JSONObject;

import com.opensymphony.xwork2.ActionSupport;

public class HworkInfoAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private JSONObject jsonObject;// 返回的json
	private String rows;// 每页显示的记录数
	private String page;// 当前第几页
	private String hwpId;
	private String claId;
	private String couId;
	private String hwName;
	private String hwCreateTime;
	private String hwInfo;
	private String hwStatus;

	public String addHwpInfo() {
		return SUCCESS;
	}

	public String updateHwpInfo() {
		return SUCCESS;
	}

	public String delHwpInfo() {
		return SUCCESS;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getHwpId() {
		return hwpId;
	}

	public void setHwpId(String hwpId) {
		this.hwpId = hwpId;
	}

	public String getClaId() {
		return claId;
	}

	public void setClaId(String claId) {
		this.claId = claId;
	}

	public String getCouId() {
		return couId;
	}

	public void setCouId(String couId) {
		this.couId = couId;
	}

	public String getHwName() {
		return hwName;
	}

	public void setHwName(String hwName) {
		this.hwName = hwName;
	}

	public String getHwCreateTime() {
		return hwCreateTime;
	}

	public void setHwCreateTime(String hwCreateTime) {
		this.hwCreateTime = hwCreateTime;
	}

	public String getHwInfo() {
		return hwInfo;
	}

	public void setHwInfo(String hwInfo) {
		this.hwInfo = hwInfo;
	}

	public String getHwStatus() {
		return hwStatus;
	}

	public void setHwStatus(String hwStatus) {
		this.hwStatus = hwStatus;
	}

}