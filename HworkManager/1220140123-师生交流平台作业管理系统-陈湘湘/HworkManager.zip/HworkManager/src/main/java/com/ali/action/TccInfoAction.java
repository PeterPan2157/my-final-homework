package com.ali.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.ali.model.TeachClaCou;
import com.ali.resultMap.TccResultMap;
import com.ali.service.TccInfoService;
import com.opensymphony.xwork2.ActionSupport;

/***
 * 
 * @author PeterPan
 * 
 */
public class TccInfoAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private TccInfoService tccInfoService;

	private JSONObject jsonObject;// 返回的json
	private String rows;// 每页显示的记录数
	private String page;// 当前第几页
	private String tccId;// tcc记录编号
	private String teachId;// 教师编号
	private String claId;// 班级编号
	private String couId;// 课程编号

	public String initData() {
		// 当前页,page由分页工具负责传过来
		int intPage = Integer.parseInt((page == null || page == "0") ? "1"
				: page);
		// 每页显示条数
		int pageSize = Integer.parseInt((rows == null || rows == "0") ? "10"
				: rows);
		// 每页的开始记录 第一页为1 第二页为number +1
		int StartNo = (intPage - 1) * pageSize;

		Map<String, Object> jsonMap = new HashMap<String, Object>();// 定义map
		List<TccResultMap> list = tccInfoService.selectAllTccRM(StartNo,
				pageSize);
		int total = tccInfoService.countAllTccRM();

		// total键存放总记录数，必须的,EasyUI根据这个参数，可以计算page和number的值，这个值不是users的长度
		jsonMap.put("total", total);
		// rows键 存放每页记录 list
		jsonMap.put("rows", list);
		// 格式化result 一定要是JSONObject
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String addTccInfo() {
		int teachId = Integer.parseInt(this.getTeachId());
		int claId = Integer.parseInt(this.getClaId());
		int couId = Integer.parseInt(this.getCouId());

		TeachClaCou teachClaCou = new TeachClaCou();
		teachClaCou.setTeachid(teachId);
		teachClaCou.setClaid(claId);
		teachClaCou.setCouid(couId);

		int result = tccInfoService.insertTccInfo(teachClaCou);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("addLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String updateTccInfo() {

		int tccId = Integer.parseInt(this.getTccId());
		int teachId = Integer.parseInt(this.getTeachId());
		int claId = Integer.parseInt(this.getClaId());
		int couId = Integer.parseInt(this.getCouId());

		TeachClaCou teachClaCou = new TeachClaCou();
		teachClaCou.setTccid(tccId);
		teachClaCou.setTeachid(teachId);
		teachClaCou.setClaid(claId);
		teachClaCou.setCouid(couId);

		int result = tccInfoService.updateByPrimaryKeySelective(teachClaCou);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("updateLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String delTccInfo() {
		int tccId = Integer.parseInt(this.getTccId());
		
		int result = tccInfoService.delTccInfoByTccId(tccId);
		
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("deleteLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public TccInfoService getTccInfoService() {
		return tccInfoService;
	}

	public void setTccInfoService(TccInfoService tccInfoService) {
		this.tccInfoService = tccInfoService;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getTeachId() {
		return teachId;
	}

	public void setTeachId(String teachId) {
		this.teachId = teachId;
	}

	public String getClaId() {
		return claId;
	}

	public void setClaId(String claId) {
		this.claId = claId;
	}

	public String getCouId() {
		return couId;
	}

	public void setCouId(String couId) {
		this.couId = couId;
	}

	public String getTccId() {
		return tccId;
	}

	public void setTccId(String tccId) {
		this.tccId = tccId;
	}

}
