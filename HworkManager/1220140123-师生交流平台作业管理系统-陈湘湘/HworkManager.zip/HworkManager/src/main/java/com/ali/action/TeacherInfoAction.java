package com.ali.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.ali.model.Teacher;
import com.ali.service.TeacherInfoService;
import com.opensymphony.xwork2.ActionSupport;

public class TeacherInfoAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private TeacherInfoService teachInfoService;
	private JSONObject jsonObject;
	private String rows;
	private String page;

	private String teachId;
	private String teachName;
	private String teachSex;
	private String teachAge;
	private String teachTel;
	private String teachEmail;

	public String initData() {
		int intPage = Integer.parseInt((page == null || page == "0") ? "1"
				: page);
		int pageSize = Integer.parseInt((rows == null || rows == "0") ? "10"
				: rows);
		int startNo = (intPage - 1) * pageSize;

		Map<String, Object> jsonMap = new HashMap<String, Object>();
		List<Teacher> list = teachInfoService.selectAllTeachInfo(startNo,
				pageSize);
		int total = teachInfoService.countTeachInfo();

		jsonMap.put("total", total);
		jsonMap.put("rows", list);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String addTeachInfo() {
		Teacher teacher = new Teacher();
		teacher.setTeachname(this.getTeachName());
		teacher.setTeachsex(this.getTeachSex());
		teacher.setTeachage(Integer.parseInt(this.getTeachAge()));
		teacher.setTeachtel(this.getTeachTel());
		teacher.setTeachemail(this.getTeachEmail());

		int result = teachInfoService.insertSelective(teacher);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("addLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String updateTeachInfo() {
		Teacher teacher = new Teacher();
		teacher.setTeachid(Integer.parseInt(this.getTeachId()));
		teacher.setTeachname(this.getTeachName());
		teacher.setTeachsex(this.getTeachSex());
		teacher.setTeachage(Integer.parseInt(this.getTeachAge()));
		teacher.setTeachtel(this.getTeachTel());
		teacher.setTeachemail(this.getTeachEmail());

		int result = teachInfoService.updateByPrimaryKeySelective(teacher);

		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("updateLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String delteachInfo() {

		int result = teachInfoService.deleteByPrimaryKey(Integer.parseInt(this
				.getTeachId()));

		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("deleteLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public TeacherInfoService getTeachInfoService() {
		return teachInfoService;
	}

	public void setTeachInfoService(TeacherInfoService teachInfoService) {
		this.teachInfoService = teachInfoService;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getTeachName() {
		return teachName;
	}

	public void setTeachName(String teachName) {
		this.teachName = teachName;
	}

	public String getTeachSex() {
		return teachSex;
	}

	public void setTeachSex(String teachSex) {
		this.teachSex = teachSex;
	}

	public String getTeachAge() {
		return teachAge;
	}

	public void setTeachAge(String teachAge) {
		this.teachAge = teachAge;
	}

	public String getTeachTel() {
		return teachTel;
	}

	public void setTeachTel(String teachTel) {
		this.teachTel = teachTel;
	}

	public String getTeachEmail() {
		return teachEmail;
	}

	public void setTeachEmail(String teachEmail) {
		this.teachEmail = teachEmail;
	}

	public String getTeachId() {
		return teachId;
	}

	public void setTeachId(String teachId) {
		this.teachId = teachId;
	}

}
