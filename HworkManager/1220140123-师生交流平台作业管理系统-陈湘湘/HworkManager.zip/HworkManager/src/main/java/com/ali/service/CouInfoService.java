package com.ali.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ali.model.Courses;

public interface CouInfoService {
	int deleteByPrimaryKey(Integer couid);

	int insert(Courses record);

	int insertSelective(Courses record);

	Courses selectByPrimaryKey(Integer couid);

	int updateByPrimaryKeySelective(Courses record);

	int updateByPrimaryKey(Courses record);

	// TODO
	List<Courses> selectAllCouInfo(@Param("startNo") Integer startNo,
			@Param("pageSize") Integer pageSize);

	int countCouInfo();

}
