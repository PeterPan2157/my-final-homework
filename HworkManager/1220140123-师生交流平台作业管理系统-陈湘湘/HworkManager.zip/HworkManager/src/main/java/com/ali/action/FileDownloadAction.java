package com.ali.action;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class FileDownloadAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private String contentType;
	private String contentDisposition;
	private InputStream inputStream;

	@Override
	public String execute() {
		String rootpath = ServletActionContext.getServletContext().getRealPath(
				"/");
		System.out.println("rootpath：" + rootpath);

		String fileName = "../document/Tomcat支持的文件类型.txt";
		System.out.println("fileName：" + fileName);

		String realpath = rootpath + fileName;
		System.out.println("realpath：" + realpath);

		try {
			inputStream = new FileInputStream(realpath);
			System.out.println("inputStream：" + inputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getContentDisposition() {
		try {
			return "attachment;filename="
					+ URLEncoder.encode("Tomcat支持的文件类型.txt", "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

}
