package com.ali.service.impl;

import java.util.List;

import com.ali.mapper.CoursesMapper;
import com.ali.model.Courses;
import com.ali.service.CouInfoService;

public class CouInfoServiceImpl implements CouInfoService {

	private CoursesMapper coursesMapper;

	public CoursesMapper getCoursesMapper() {
		return coursesMapper;
	}

	public void setCoursesMapper(CoursesMapper coursesMapper) {
		this.coursesMapper = coursesMapper;
	}

	public int deleteByPrimaryKey(Integer couid) {
		return coursesMapper.deleteByPrimaryKey(couid);
	}

	public int insert(Courses record) {
		return coursesMapper.insert(record);
	}

	public int insertSelective(Courses record) {
		return coursesMapper.insertSelective(record);
	}

	public Courses selectByPrimaryKey(Integer couid) {
		return coursesMapper.selectByPrimaryKey(couid);
	}

	public int updateByPrimaryKeySelective(Courses record) {
		return coursesMapper.updateByPrimaryKeySelective(record);
	}

	public int updateByPrimaryKey(Courses record) {
		return coursesMapper.updateByPrimaryKey(record);
	}

	// TODO
	public List<Courses> selectAllCouInfo(Integer startNo, Integer pageSize) {
		return coursesMapper.selectAllCouInfo(startNo, pageSize);
	}

	public int countCouInfo() {
		return coursesMapper.countCouInfo();
	}

}
