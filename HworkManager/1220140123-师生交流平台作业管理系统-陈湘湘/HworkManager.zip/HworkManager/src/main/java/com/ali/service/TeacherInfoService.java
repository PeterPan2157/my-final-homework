package com.ali.service;

import java.util.List;

import com.ali.model.Teacher;

public interface TeacherInfoService {
	int deleteByPrimaryKey(Integer teachid);

	int insert(Teacher record);

	int insertSelective(Teacher record);

	Teacher selectByPrimaryKey(Integer teachid);

	int updateByPrimaryKeySelective(Teacher record);

	int updateByPrimaryKey(Teacher record);

	// TODO：开始写自己的方法
	List<Teacher> selectAllTeachInfo(Integer startNo, Integer pageSize);

	int countTeachInfo();

}
