package com.ali.service.impl;

import java.util.List;

import com.ali.mapper.ClassesMapper;
import com.ali.model.Classes;
import com.ali.service.ClaInfoService;

public class ClaInfoServiceImpl implements ClaInfoService {

	private ClassesMapper classesMapper;

	public ClassesMapper getClassesMapper() {
		return classesMapper;
	}

	public void setClassesMapper(ClassesMapper classesMapper) {
		this.classesMapper = classesMapper;
	}

	public int deleteByPrimaryKey(Integer claid) {
		return classesMapper.deleteByPrimaryKey(claid);
	}

	public int insert(Classes record) {
		return classesMapper.insert(record);
	}

	public int insertSelective(Classes record) {
		return classesMapper.insertSelective(record);
	}

	public Classes selectByPrimaryKey(Integer claid) {
		return classesMapper.selectByPrimaryKey(claid);
	}

	public int updateByPrimaryKeySelective(Classes record) {
		return classesMapper.updateByPrimaryKeySelective(record);
	}

	public int updateByPrimaryKey(Classes record) {
		return classesMapper.updateByPrimaryKey(record);
	}

	public List<Classes> selectAllClaInfo(Integer startNo, Integer pageSize) {
		return classesMapper.selectAllClaInfo(startNo, pageSize);
	}

	public int countClaInfo() {
		return classesMapper.countClaInfo();
	}

}
