package com.ali.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.struts2.ServletActionContext;

import com.ali.model.Homework;
import com.ali.service.HomeworkService;
import com.opensymphony.xwork2.ActionSupport;

public class FileUploadAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private File upload;
	private String homeworkId;
	private String studentId;
	private String uploadContentType;
	private String uploadFileName;
	private HomeworkService homeworkService;
	private String savepath;

	public String getHomeworkId() {
		return homeworkId;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public void setHomeworkId(String homeworkId) {
		this.homeworkId = homeworkId;
	}

	public HomeworkService getHomeworkService() {
		return homeworkService;
	}

	public void setHomeworkService(HomeworkService homeworkService) {
		this.homeworkService = homeworkService;
	}

	public File getUpload() {
		return upload;
	}

	public void setUpload(File upload) {
		this.upload = upload;
	}

	public String getUploadContentType() {
		return uploadContentType;
	}

	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	public String getUploadFileName() {
		return uploadFileName;
	}

	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	public String getSavepath() {
		return savepath;
	}

	public void setSavepath(String savepath) {
		this.savepath = savepath;
	}

	@Override
	public String execute() {
		String rootpath = ServletActionContext.getServletContext().getRealPath(
				"/");
		String realpath = rootpath + savepath + uploadFileName;
		System.out.println(realpath);
		FileOutputStream fos = null;
		FileInputStream fis = null;
		try {
			fos = new FileOutputStream(realpath);
			fis = new FileInputStream(upload);
			byte[] buffer = new byte[1024];
			int length = 0;
			while ((length = fis.read(buffer)) != -1) {
				fos.write(buffer, 0, length);
			}
			Homework hw = new Homework();
			hw.setHwpid(Integer.parseInt(this.getHomeworkId()));
			hw.setStuid(Integer.parseInt(this.getStudentId()));
			hw.setHwpath(savepath + uploadFileName);
			hw.setHwstatus("已完成");
			homeworkService.updateHwPath(hw);
		} catch (FileNotFoundException e) {
			throw new RuntimeException("找不到文件", e);
		} catch (IOException e) {
			throw new RuntimeException("文件上传异常", e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				throw new RuntimeException("输入流关闭异常", e);
			}
			try {
				fos.close();
			} catch (IOException e) {
				throw new RuntimeException("输出流关闭异常", e);
			}
		}
		return "success";
	}
}
