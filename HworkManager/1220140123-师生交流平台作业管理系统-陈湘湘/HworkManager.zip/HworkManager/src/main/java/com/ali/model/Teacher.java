package com.ali.model;

public class Teacher {
    private Integer teachid;

	private String teachname;

	private String teachpwd;

	private String teachsex;

	private Integer teachage;

	private String teachtel;

	private String teachemail;

	private String teachstatus;

	public Integer getTeachid() {
		return teachid;
	}

	public void setTeachid(Integer teachid) {
		this.teachid = teachid;
	}

	public String getTeachname() {
		return teachname;
	}

	public void setTeachname(String teachname) {
		this.teachname = teachname;
	}

	public String getTeachpwd() {
		return teachpwd;
	}

	public void setTeachpwd(String teachpwd) {
		this.teachpwd = teachpwd;
	}

	public String getTeachsex() {
		return teachsex;
	}

	public void setTeachsex(String teachsex) {
		this.teachsex = teachsex;
	}

	public Integer getTeachage() {
		return teachage;
	}

	public void setTeachage(Integer teachage) {
		this.teachage = teachage;
	}

	public String getTeachtel() {
		return teachtel;
	}

	public void setTeachtel(String teachtel) {
		this.teachtel = teachtel;
	}

	public String getTeachemail() {
		return teachemail;
	}

	public void setTeachemail(String teachemail) {
		this.teachemail = teachemail;
	}

	public String getTeachstatus() {
		return teachstatus;
	}

	public void setTeachstatus(String teachstatus) {
		this.teachstatus = teachstatus;
	}

	
}