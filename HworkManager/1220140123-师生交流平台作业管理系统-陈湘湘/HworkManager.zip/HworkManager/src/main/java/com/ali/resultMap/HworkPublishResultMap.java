package com.ali.resultMap;



public class HworkPublishResultMap {
	private Integer hwpid;
	private Integer couid;
	private String couname;
	private Integer claid;
	private String claname;
	private String hwname;
	private String hwcreatetime;
	private String hwinfo;
	private String hwpstatus;

	public Integer getHwpid() {
		return hwpid;
	}

	public void setHwpid(Integer hwpid) {
		this.hwpid = hwpid;
	}

	public Integer getCouid() {
		return couid;
	}

	public void setCouid(Integer couid) {
		this.couid = couid;
	}

	public String getCouname() {
		return couname;
	}

	public void setCouname(String couname) {
		this.couname = couname;
	}

	public Integer getClaid() {
		return claid;
	}

	public void setClaid(Integer claid) {
		this.claid = claid;
	}

	public String getClaname() {
		return claname;
	}

	public void setClaname(String claname) {
		this.claname = claname;
	}

	public String getHwname() {
		return hwname;
	}

	public String getHwcreatetime() {
		return hwcreatetime;
	}

	public void setHwcreatetime(String hwcreatetime) {
		this.hwcreatetime = hwcreatetime;
	}

	public void setHwname(String hwname) {
		this.hwname = hwname;
	}

	

	public String getHwinfo() {
		return hwinfo;
	}

	public void setHwinfo(String hwinfo) {
		this.hwinfo = hwinfo;
	}

	public String getHwpstatus() {
		return hwpstatus;
	}

	public void setHwpstatus(String hwpstatus) {
		this.hwpstatus = hwpstatus;
	}

	@Override
	public String toString() {
		return "HworkPublishResultMap [hwpid=" + hwpid + ", couid=" + couid
				+ ", couname=" + couname + ", claid=" + claid + ", claname="
				+ claname + ", hwname=" + hwname + ", hwcreatetime="
				+ hwcreatetime + ", hwinfo=" + hwinfo + ", hwpstatus="
				+ hwpstatus + "]";
	}

}