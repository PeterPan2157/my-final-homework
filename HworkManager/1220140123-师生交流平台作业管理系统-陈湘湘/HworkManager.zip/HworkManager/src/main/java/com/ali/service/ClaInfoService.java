package com.ali.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ali.model.Classes;

public interface ClaInfoService {
    int deleteByPrimaryKey(Integer claid);

    int insert(Classes record);

    int insertSelective(Classes record);

    Classes selectByPrimaryKey(Integer claid);

    int updateByPrimaryKeySelective(Classes record);

    int updateByPrimaryKey(Classes record);
    
	// TODO
	List<Classes> selectAllClaInfo(@Param("startNo") Integer startNo,
			@Param("pageSize") Integer pageSize);

	int countClaInfo();
	
}
