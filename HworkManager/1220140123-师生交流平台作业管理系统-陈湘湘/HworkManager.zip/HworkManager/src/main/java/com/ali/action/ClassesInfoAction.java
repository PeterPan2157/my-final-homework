package com.ali.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.ali.model.Classes;
import com.ali.service.ClaInfoService;
import com.opensymphony.xwork2.ActionSupport;

public class ClassesInfoAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private ClaInfoService claInfoService;
	private JSONObject jsonObject;// 返回的json
	private String rows;// 每页显示的记录数
	private String page;// 当前第几页

	private String claId;
	private String claName;

	public String initData() {
		int intPage = Integer.parseInt((page == null || page == "0") ? "1"
				: page);
		int pageSize = Integer.parseInt((rows == null || rows == "0") ? "10"
				: rows);
		int startNo = (intPage - 1) * pageSize;

		Map<String, Object> jsonMap = new HashMap<String, Object>();
		List<Classes> list = claInfoService.selectAllClaInfo(startNo, pageSize);
		int total = claInfoService.countClaInfo();

		// total键存放总记录数，必须的,EasyUI根据这个参数，可以计算page和number的值，这个值不是users的长度
		jsonMap.put("total", total);
		// rows键 存放每页记录 list
		jsonMap.put("rows", list);
		// 格式化result 一定要是JSONObject
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String addClaInfo() {
		Classes classes = new Classes();
		classes.setClaname(this.getClaName());

		int result = claInfoService.insertSelective(classes);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("addLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String updateClaInfo() {
		Classes classes = new Classes();
		classes.setClaid(Integer.parseInt(this.getClaId()));
		classes.setClaname(this.getClaName());

		int result = claInfoService.updateByPrimaryKeySelective(classes);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("updateLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String delClaInfo() {

		int result = claInfoService.deleteByPrimaryKey(Integer.parseInt(this
				.getClaId()));
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("deleteLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public ClaInfoService getClaInfoService() {
		return claInfoService;
	}

	public void setClaInfoService(ClaInfoService claInfoService) {
		this.claInfoService = claInfoService;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getClaId() {
		return claId;
	}

	public void setClaId(String claId) {
		this.claId = claId;
	}

	public String getClaName() {
		return claName;
	}

	public void setClaName(String claName) {
		this.claName = claName;
	}
}
