package com.ali.service;

import com.ali.model.Students;

public interface LoginService {
	public Students frontLogin(String userId, String userPwd);

}
