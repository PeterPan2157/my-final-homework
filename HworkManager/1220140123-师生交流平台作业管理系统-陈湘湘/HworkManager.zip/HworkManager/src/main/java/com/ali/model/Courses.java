package com.ali.model;

public class Courses {
    private Integer couid;

    private String couname;

    private String coustatus;

    public Integer getCouid() {
        return couid;
    }

    public void setCouid(Integer couid) {
        this.couid = couid;
    }

    public String getCouname() {
        return couname;
    }

    public void setCouname(String couname) {
        this.couname = couname;
    }

    public String getCoustatus() {
        return coustatus;
    }

    public void setCoustatus(String coustatus) {
        this.coustatus = coustatus;
    }
}