package com.ali.service;

import java.util.List;

import com.ali.model.Homework;
import com.ali.model.HworkPublish;
import com.ali.model.Students;
import com.ali.resultMap.StuHomeworkResultMap;

public interface HomeworkService {
	int deleteByPrimaryKey(Integer hwid);

	int insert(Homework record);

	int insertSelective(Homework record);

	Homework selectByPrimaryKey(Integer hwid);

	int updateByPrimaryKeySelective(Homework record);

	int updateByPrimaryKey(Homework record);

	// TODO
	/**
	 * 查询学生作业表中所有的作业
	 * 
	 * @param stuId
	 * @return
	 */
	public List<Homework> selectStuHomeworkByStuId(Integer stuId);

	/**
	 * 查询某个班被发布的作业（作业发布表中）
	 * 
	 * @param claId
	 * @return
	 */
	public List<HworkPublish> selectHworkPublishByClaId(Integer claId);

	/**
	 * 查询学生某一课程下的所有作业
	 * 
	 * @param stuId
	 * @param couId
	 * @return
	 */
	public List<Homework> selectStuHomeworkByCouId(Integer stuId, Integer couId);

	/**
	 * 查询班级某一课程下的所有作业
	 * 
	 * @param claId
	 * @param couId
	 * @return
	 */
	public List<HworkPublish> selectHworkPublishByCouId(Integer claId,
			Integer couId);

	/**
	 * 统计学生作业表数目（某一个学生的）
	 * 
	 * @return
	 */
	public int countHomeworkByStuId(Integer stuId);

	/**
	 * 统计发布表数目（某一个班级的）
	 * 
	 * @return
	 */
	public int countHworkPublishByClaId(Integer claId);

	/**
	 * 同步作业表
	 */
	public void updateHomework(Students students);

	/**
	 * 查询某个学生名下所有的作业
	 * 
	 * @param stuId
	 * @return
	 */
	public List<StuHomeworkResultMap> selectAllHomeworkByStuId(Integer stuId);

	public int updateHwPath(Homework record);
}