package com.ali.model;


public class HworkPublish {
	private Integer hwpid;

	private Integer couid;

	private Integer claid;

	private String hwname;

	private String hwcreatetime;

	private String hwinfo;

	private String hwpstatus;

	public Integer getHwpid() {
		return hwpid;
	}

	public void setHwpid(Integer hwpid) {
		this.hwpid = hwpid;
	}

	public Integer getCouid() {
		return couid;
	}

	public void setCouid(Integer couid) {
		this.couid = couid;
	}

	public Integer getClaid() {
		return claid;
	}

	public void setClaid(Integer claid) {
		this.claid = claid;
	}

	public String getHwname() {
		return hwname;
	}

	public void setHwname(String hwname) {
		this.hwname = hwname;
	}

	public String getHwcreatetime() {
		return hwcreatetime;
	}

	public void setHwcreatetime(String hwcreatetime) {
		this.hwcreatetime = hwcreatetime;
	}

	public String getHwinfo() {
		return hwinfo;
	}

	public void setHwinfo(String hwinfo) {
		this.hwinfo = hwinfo;
	}

	public String getHwpstatus() {
		return hwpstatus;
	}

	public void setHwpstatus(String hwpstatus) {
		this.hwpstatus = hwpstatus;
	}

	@Override
	public String toString() {
		return "HworkPublish [hwpid=" + hwpid + ", couid=" + couid + ", claid="
				+ claid + ", hwname=" + hwname + ", hwcreatetime="
				+ hwcreatetime + ", hwinfo=" + hwinfo + ", hwpstatus="
				+ hwpstatus + "]";
	}
	
}