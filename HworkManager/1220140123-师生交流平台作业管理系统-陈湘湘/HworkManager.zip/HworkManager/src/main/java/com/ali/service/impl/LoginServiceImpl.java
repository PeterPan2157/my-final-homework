package com.ali.service.impl;

import com.ali.mapper.StudentsMapper;
import com.ali.model.Students;
import com.ali.service.LoginService;

public class LoginServiceImpl implements LoginService {
	private StudentsMapper studentsMapper;

	public Students frontLogin(String userId, String userPwd) {
		Students students = studentsMapper.selectByPrimaryKey(Integer
				.parseInt(userId));

		if (students != null && userPwd.equals(students.getStupwd())) {
			return students;
		} else {
			return null;
		}

	}

	public StudentsMapper getStudentsMapper() {
		return studentsMapper;
	}

	public void setStudentsMapper(StudentsMapper studentsMapper) {
		this.studentsMapper = studentsMapper;
	}

}
