package com.ali.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ali.model.HworkPublish;
import com.ali.resultMap.HworkPublishResultMap;

public interface HworkPublishMapper {
	int deleteByPrimaryKey(Integer hwpid);

	int insert(HworkPublish record);

	int insertSelective(HworkPublish record);

	HworkPublish selectByPrimaryKey(Integer hwpid);

	int updateByPrimaryKeySelective(HworkPublish record);

	int updateByPrimaryKey(HworkPublish record);

	/**
	 * 查询某个班被发布的作业（作业发布表中）
	 * 
	 * @param claId
	 * @return
	 */
	public List<HworkPublish> selectHworkPublishByClaId(
			@Param("claId") Integer claId);

	/**
	 * 查询班级某一课程下的所有作业
	 * 
	 * @param claId
	 * @param couId
	 * @return
	 */
	public List<HworkPublish> selectHworkPublishByCouId(
			@Param("claId") Integer claId, @Param("couId") Integer couId);

	/**
	 * 统计发布表数目
	 * 
	 * @return
	 */
	public int countHworkPublishByClaId(@Param("claId") Integer claId);

	public List<HworkPublishResultMap> selectAllHwpRM(@Param("startNo")Integer startNo,
			@Param("pageSize")Integer pageSize);

	public int countHworkPublishInfo();

}