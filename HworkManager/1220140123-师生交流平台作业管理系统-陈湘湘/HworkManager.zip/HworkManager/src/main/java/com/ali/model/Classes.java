package com.ali.model;

public class Classes {
    private Integer claid;

    private String claname;

    private String clastatus;

    public Integer getClaid() {
        return claid;
    }

    public void setClaid(Integer claid) {
        this.claid = claid;
    }

    public String getClaname() {
        return claname;
    }

    public void setClaname(String claname) {
        this.claname = claname;
    }

    public String getClastatus() {
        return clastatus;
    }

    public void setClastatus(String clastatus) {
        this.clastatus = clastatus;
    }
}