package com.ali.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Dao {

	// 静态数据，本该从数据库查出来的成为一个集合
	private static Map<String, FileItem> files = new HashMap<String, FileItem>();
	static {
		long id = System.currentTimeMillis();
		String fileId = "100" + id;
		files.put(fileId, new FileItem(fileId, "9-10.txt", "text/plain",
				"images\\9-10.txt", 206));
		fileId = "200" + id;
		files.put(fileId, new FileItem(fileId, "aaa.xml", "text/xml",
				"images\\aaa.xml", 156));
		fileId = "300" + id;
		files.put(fileId, new FileItem(fileId, "test.xml", "application/xml",
				"images\\test.xml", 617));
		fileId = "400" + id;
		files.put(fileId, new FileItem(fileId, "Tomcat支持的文件类型.txt",
				"text/plain", "document\\Tomcat支持的文件类型.txt", 21 * 1024));
	}

	// 获得文件下载列表
	public List<FileItem> getFileList() {
		return new ArrayList<FileItem>(files.values());
	}

	// 根据id获得单个文件
	public FileItem getFileItem(String fileName) {
		return files.get(fileName);
	}
}
