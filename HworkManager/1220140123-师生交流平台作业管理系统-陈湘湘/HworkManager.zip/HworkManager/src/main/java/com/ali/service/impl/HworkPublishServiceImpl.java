package com.ali.service.impl;

import java.util.List;

import com.ali.mapper.HworkPublishMapper;
import com.ali.model.HworkPublish;
import com.ali.resultMap.HworkPublishResultMap;
import com.ali.service.HworkPublishService;

public class HworkPublishServiceImpl implements HworkPublishService {
	private HworkPublishMapper hworkPublishMapper;

	public HworkPublishMapper getHworkPublishMapper() {
		return hworkPublishMapper;
	}

	public void setHworkPublishMapper(HworkPublishMapper hworkPublishMapper) {
		this.hworkPublishMapper = hworkPublishMapper;
	}

	public int deleteByPrimaryKey(Integer hwpid) {
		return hworkPublishMapper.deleteByPrimaryKey(hwpid);
	}

	public int insert(HworkPublish record) {
		return hworkPublishMapper.insert(record);
	}

	public int insertSelective(HworkPublish record) {
		return hworkPublishMapper.insertSelective(record);
	}

	public HworkPublish selectByPrimaryKey(Integer hwpid) {
		return hworkPublishMapper.selectByPrimaryKey(hwpid);
	}

	public int updateByPrimaryKeySelective(HworkPublish record) {
		return hworkPublishMapper.updateByPrimaryKeySelective(record);
	}

	public int updateByPrimaryKey(HworkPublish record) {
		return hworkPublishMapper.updateByPrimaryKey(record);
	}

	public List<HworkPublish> selectHworkPublishByClaId(Integer claId) {
		return hworkPublishMapper.selectHworkPublishByClaId(claId);
	}

	public List<HworkPublish> selectHworkPublishByCouId(Integer claId,
			Integer couId) {
		return hworkPublishMapper.selectHworkPublishByCouId(claId, couId);
	}

	public int countHworkPublishByClaId(Integer claId) {
		return hworkPublishMapper.countHworkPublishByClaId(claId);
	}

	public List<HworkPublishResultMap> selectAllHwpRM(Integer startNo,
			Integer pageSize) {
		return hworkPublishMapper.selectAllHwpRM(startNo, pageSize);
	}

	public int countHworkPublishInfo() {
		return hworkPublishMapper.countHworkPublishInfo();
	}

}
