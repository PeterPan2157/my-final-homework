package com.ali.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.ali.model.HworkPublish;
import com.ali.resultMap.HworkPublishResultMap;
import com.ali.service.HworkPublishService;
import com.opensymphony.xwork2.ActionSupport;

public class HworkPublishInfoAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private JSONObject jsonObject;// 返回的json
	private HworkPublishService hworkPublishService;
	private String rows;// 每页显示的记录数
	private String page;// 当前第几页
	private String hwpId;
	private String claId;
	private String couId;
	private String hwName;
	private String hwCreateTime;
	private String hwInfo;
	private String hwStatus;

	public String initData() {
		int intPage = Integer.parseInt((page == null || page == "0") ? "1"
				: page);
		int pageSize = Integer.parseInt((rows == null || rows == "0") ? "10"
				: rows);
		int startNo = (intPage - 1) * pageSize;

		Map<String, Object> jsonMap = new HashMap<String, Object>();
		List<HworkPublishResultMap> list = hworkPublishService.selectAllHwpRM(
				startNo, pageSize);
		int total = hworkPublishService.countHworkPublishInfo();

		jsonMap.put("total", total);
		jsonMap.put("rows", list);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String addHwpInfo() {
		HworkPublish hworkPublish = new HworkPublish();
		hworkPublish.setClaid(Integer.parseInt(this.getClaId()));
		hworkPublish.setCouid(Integer.parseInt(this.getCouId()));
		hworkPublish.setHwname(this.getHwName());
		hworkPublish.setHwcreatetime(this.getHwCreateTime());
		hworkPublish.setHwinfo(this.getHwInfo());
		hworkPublish.setHwpstatus(this.getHwStatus());

		int result = hworkPublishService.insertSelective(hworkPublish);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("addLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String updateHwpInfo() {
		HworkPublish hworkPublish = new HworkPublish();

		hworkPublish.setHwpid(Integer.parseInt(this.getHwpId()));
		hworkPublish.setClaid(Integer.parseInt(this.getClaId()));
		hworkPublish.setCouid(Integer.parseInt(this.getCouId()));
		hworkPublish.setHwname(this.getHwName());
		hworkPublish.setHwcreatetime(this.getHwCreateTime());
		hworkPublish.setHwinfo(this.getHwInfo());
		hworkPublish.setHwpstatus(this.getHwStatus());

		int result = hworkPublishService
				.updateByPrimaryKeySelective(hworkPublish);

		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("updateLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String delHwpInfo() {

		int result = hworkPublishService.deleteByPrimaryKey(Integer
				.parseInt(this.getHwpId()));

		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("deleteLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getHwpId() {
		return hwpId;
	}

	public void setHwpId(String hwpId) {
		this.hwpId = hwpId;
	}

	public String getClaId() {
		return claId;
	}

	public void setClaId(String claId) {
		this.claId = claId;
	}

	public String getCouId() {
		return couId;
	}

	public void setCouId(String couId) {
		this.couId = couId;
	}

	public String getHwName() {
		return hwName;
	}

	public void setHwName(String hwName) {
		this.hwName = hwName;
	}

	public String getHwInfo() {
		return hwInfo;
	}

	public void setHwInfo(String hwInfo) {
		this.hwInfo = hwInfo;
	}

	public String getHwStatus() {
		return hwStatus;
	}

	public void setHwStatus(String hwStatus) {
		this.hwStatus = hwStatus;
	}

	public HworkPublishService getHworkPublishService() {
		return hworkPublishService;
	}

	public void setHworkPublishService(HworkPublishService hworkPublishService) {
		this.hworkPublishService = hworkPublishService;
	}

	public String getHwCreateTime() {
		return hwCreateTime;
	}

	public void setHwCreateTime(String hwCreateTime) {
		this.hwCreateTime = hwCreateTime;
	}
}
