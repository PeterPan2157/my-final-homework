package com.ali.service.impl;

import java.util.List;

import com.ali.mapper.StudentsMapper;
import com.ali.model.Students;
import com.ali.resultMap.StuResultMap;
import com.ali.service.StuInfoService;

public class StuInfoServiceImpl implements StuInfoService {
	private StudentsMapper studentsMapper;

	public StudentsMapper getStudentsMapper() {
		return studentsMapper;
	}

	public void setStudentsMapper(StudentsMapper studentsMapper) {
		this.studentsMapper = studentsMapper;
	}

	public int deleteByPrimaryKey(Integer stuid) {
		return studentsMapper.deleteByPrimaryKey(stuid);
	}

	public int insert(Students record) {
		return studentsMapper.insert(record);
	}

	public int insertSelective(Students record) {
		return studentsMapper.insertSelective(record);
	}

	public Students selectByPrimaryKey(Integer stuid) {
		return studentsMapper.selectByPrimaryKey(stuid);
	}

	public int updateByPrimaryKeySelective(Students record) {
		return studentsMapper.updateByPrimaryKeySelective(record);
	}

	public int updateByPrimaryKey(Students record) {
		return studentsMapper.updateByPrimaryKey(record);
	}

	public List<StuResultMap> selectAllStuInfo(Integer startNo, Integer pageSize) {
		return studentsMapper.selectAllStuInfo(startNo, pageSize);
	}

	public int countStuInfo() {
		return studentsMapper.countStuInfo();
	}

}
