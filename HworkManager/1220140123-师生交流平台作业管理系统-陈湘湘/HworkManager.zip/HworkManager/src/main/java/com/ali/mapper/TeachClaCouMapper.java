package com.ali.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ali.model.Courses;
import com.ali.model.TeachClaCou;
import com.ali.resultMap.TccResultMap;

public interface TeachClaCouMapper {
	int deleteByPrimaryKey(Integer tccid);

	int insert(TeachClaCou record);

	int insertSelective(TeachClaCou record);

	TeachClaCou selectByPrimaryKey(Integer tccid);

	int updateByPrimaryKeySelective(TeachClaCou record);

	int updateByPrimaryKey(TeachClaCou record);

	// 我新增的几个条件查询
	List<TeachClaCou> selectTccByClaId(@Param("claId") Integer claId,
			@Param("StartNo") Integer StartNo, @Param("pageSize") Integer pageSize);

	List<TeachClaCou> selectTccByCouId(@Param("couId") Integer couId,
			@Param("StartNo") Integer StartNo, @Param("pageSize") Integer pageSize);

	List<TeachClaCou> selectTccByTeachId(@Param("teachId") Integer teachId,
			@Param("StartNo") Integer StartNo, @Param("pageSize") Integer pageSize);

	// 为了前台数据处理方便，增加的一个resultMap数据处理方式
	int countAllTccRM();

	List<TccResultMap> selectAllTccRM(@Param("StartNo") Integer StartNo,
			@Param("pageSize") Integer pageSize);

	TccResultMap selectTccRMByTccId(@Param("tccId") Integer tccId,
			@Param("StartNo") Integer StartNo, @Param("pageSize") Integer pageSize);

	List<TccResultMap> selectTccRMByClaId(@Param("claId") Integer claId,
			@Param("StartNo") Integer StartNo, @Param("pageSize") Integer pageSize);

	List<TccResultMap> selectTccRMByCouId(@Param("couId") Integer couId,
			@Param("StartNo") Integer StartNo, @Param("pageSize") Integer pageSize);

	List<TccResultMap> selectTccRMByTeachId(@Param("teachId") Integer teachId,
			@Param("StartNo") Integer StartNo, @Param("pageSize") Integer pageSize);

	public List<Courses> selectCouByClaId(Integer claId);
}