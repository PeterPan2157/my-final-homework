package com.ali.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.ali.model.Courses;
import com.ali.service.CouInfoService;
import com.opensymphony.xwork2.ActionSupport;

public class CoursesInfoAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private CouInfoService couInfoService;
	private JSONObject jsonObject;// 返回的json
	private String rows;// 每页显示的记录数
	private String page;// 当前第几页

	private String couId;
	private String couName;

	public String initData() {
		int intPage = Integer.parseInt((page == null || page == "0") ? "1"
				: page);
		int pageSize = Integer.parseInt((rows == null || rows == "0") ? "10"
				: rows);
		int startNo = (intPage - 1) * pageSize;

		Map<String, Object> jsonMap = new HashMap<String, Object>();
		List<Courses> list = couInfoService.selectAllCouInfo(startNo, pageSize);
		int total = couInfoService.countCouInfo();

		// total键存放总记录数，必须的,EasyUI根据这个参数，可以计算page和number的值，这个值不是users的长度
		jsonMap.put("total", total);
		// rows键 存放每页记录 list
		jsonMap.put("rows", list);
		// 格式化result 一定要是JSONObject
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String addCouInfo() {
		Courses courses = new Courses();
		courses.setCouname(this.getCouName());

		int result = couInfoService.insertSelective(courses);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("addLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String updateCouInfo() {

		Courses courses = new Courses();
		courses.setCouid(Integer.parseInt(this.getCouId()));
		courses.setCouname(this.getCouName());

		int result = couInfoService.updateByPrimaryKeySelective(courses);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("updateLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String delCouInfo() {
		int result = couInfoService.deleteByPrimaryKey(Integer.parseInt(this
				.getCouId()));

		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("deleteLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public CouInfoService getCouInfoService() {
		return couInfoService;
	}

	public void setCouInfoService(CouInfoService couInfoService) {
		this.couInfoService = couInfoService;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getCouId() {
		return couId;
	}

	public void setCouId(String couId) {
		this.couId = couId;
	}

	public String getCouName() {
		return couName;
	}

	public void setCouName(String couName) {
		this.couName = couName;
	}

}
