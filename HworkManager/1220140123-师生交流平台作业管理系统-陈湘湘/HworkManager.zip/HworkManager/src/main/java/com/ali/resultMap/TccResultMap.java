package com.ali.resultMap;

public class TccResultMap {
	private Integer tccid;

	private Integer teachid;
	private String teachname;

	private Integer claid;
	private String claname;

	private Integer couid;
	private String couname;

	private String tccstatus;

	public Integer getTccid() {
		return tccid;
	}

	public void setTccid(Integer tccid) {
		this.tccid = tccid;
	}

	public Integer getTeachid() {
		return teachid;
	}

	public void setTeachid(Integer teachid) {
		this.teachid = teachid;
	}

	public String getTeachname() {
		return teachname;
	}

	public void setTeachname(String teachname) {
		this.teachname = teachname;
	}

	public Integer getClaid() {
		return claid;
	}

	public void setClaid(Integer claid) {
		this.claid = claid;
	}

	public String getClaname() {
		return claname;
	}

	public void setClaname(String claname) {
		this.claname = claname;
	}

	public Integer getCouid() {
		return couid;
	}

	public void setCouid(Integer couid) {
		this.couid = couid;
	}

	public String getCouname() {
		return couname;
	}

	public void setCouname(String couname) {
		this.couname = couname;
	}

	public String getTccstatus() {
		return tccstatus;
	}

	public void setTccstatus(String tccstatus) {
		this.tccstatus = tccstatus;
	}

	@Override
	public String toString() {
		return "TccResultMap [tccid=" + tccid + ", teachid=" + teachid
				+ ", teachname=" + teachname + ", claid=" + claid
				+ ", claname=" + claname + ", couid=" + couid + ", couname="
				+ couname + ", tccstatus=" + tccstatus + "]";
	}

}
