package com.ali.service.impl;

import java.util.List;

import com.ali.mapper.TeachClaCouMapper;
import com.ali.model.Courses;
import com.ali.model.Students;
import com.ali.model.TeachClaCou;
import com.ali.resultMap.TccResultMap;
import com.ali.service.TccInfoService;

public class TccInfoServiceImpl implements TccInfoService {

	private TeachClaCouMapper teachClaCouMapper;

	public TeachClaCouMapper getTeachClaCouMapper() {
		return teachClaCouMapper;
	}

	public void setTeachClaCouMapper(TeachClaCouMapper teachClaCouMapper) {
		this.teachClaCouMapper = teachClaCouMapper;
	}

	public int insertTccInfo(TeachClaCou teachClaCou) {
		return teachClaCouMapper.insertSelective(teachClaCou);
	}

	public int delTccInfoByTccId(int tccId) {
		return teachClaCouMapper.deleteByPrimaryKey(tccId);
	}

	public int updateTccInfo(TeachClaCou teachClaCou) {
		return teachClaCouMapper.updateByPrimaryKey(teachClaCou);
	}

	public int updateByPrimaryKeySelective(TeachClaCou teachClaCou) {
		return teachClaCouMapper.updateByPrimaryKeySelective(teachClaCou);
	}

	public TeachClaCou selectTccByPrimaryKey(int tccId) {
		return teachClaCouMapper.selectByPrimaryKey(tccId);
	}

	public List<TeachClaCou> selectTccByClaId(int claId, int StartNo,
			int pageSize) {
		return teachClaCouMapper.selectTccByClaId(claId, StartNo, pageSize);
	}

	public List<TeachClaCou> selectTccByCouId(int couId, int StartNo,
			int pageSize) {
		return teachClaCouMapper.selectTccByCouId(couId, StartNo, pageSize);
	}

	public List<TeachClaCou> selectTccByTeachId(int teachId, int StartNo,
			int pageSize) {
		return teachClaCouMapper.selectTccByTeachId(teachId, StartNo, pageSize);
	}

	public TccResultMap selectTccRMByPrimaryKey(int tccId, int StartNo,
			int pageSize) {
		return teachClaCouMapper.selectTccRMByTccId(tccId, StartNo, pageSize);
	}

	public List<TccResultMap> selectTccRMByClaId(int claId, int StartNo,
			int pageSize) {
		return teachClaCouMapper.selectTccRMByClaId(claId, StartNo, pageSize);
	}

	public List<TccResultMap> selectTccRMByCouId(int couId, int StartNo,
			int pageSize) {
		return teachClaCouMapper.selectTccRMByCouId(couId, StartNo, pageSize);
	}

	public List<TccResultMap> selectTccRMByTeachId(int teachId, int StartNo,
			int pageSize) {
		return teachClaCouMapper.selectTccRMByTeachId(teachId, StartNo,
				pageSize);
	}

	public List<TccResultMap> selectAllTccRM(int StartNo, int pageSize) {
		return teachClaCouMapper.selectAllTccRM(StartNo, pageSize);
	}

	public int countAllTccRM() {
		return teachClaCouMapper.countAllTccRM();
	}

	// 查询学生所在班级的所有课程
	public List<Courses> selectCouByClaId(Students students) {
		return teachClaCouMapper.selectCouByClaId(students.getClaid());
	}
}
