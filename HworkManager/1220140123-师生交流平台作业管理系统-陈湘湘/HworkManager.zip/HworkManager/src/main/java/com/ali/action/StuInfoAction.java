package com.ali.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.ali.model.Students;
import com.ali.resultMap.StuResultMap;
import com.ali.service.StuInfoService;
import com.opensymphony.xwork2.ActionSupport;

public class StuInfoAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private StuInfoService stuInfoService;
	private JSONObject jsonObject;// 返回的json
	private String rows;// 每页显示的记录数
	private String page;// 当前第几页

	private String stuId;
	private String stuName;
	private String claId;
	private String stuSex;
	private String stuAge;
	private String stuTel;
	private String stuEmail;

	public String initData() {
		int intPage = Integer.parseInt((page == null || page == "0") ? "1"
				: page);
		int pageSize = Integer.parseInt((rows == null || rows == "0") ? "10"
				: rows);
		int startNo = (intPage - 1) * pageSize;

		Map<String, Object> jsonMap = new HashMap<String, Object>();
		List<StuResultMap> list = stuInfoService.selectAllStuInfo(startNo,
				pageSize);
		int total = stuInfoService.countStuInfo();

		jsonMap.put("total", total);
		jsonMap.put("rows", list);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public String addStuInfo() {
		Students students = new Students();
		students.setStuname(this.getStuName());
		students.setClaid(Integer.parseInt(this.getClaId()));
		students.setStusex(this.getStuSex());
		students.setStuage(Integer.parseInt(this.getStuAge()));
		students.setStutel(this.getStuTel());
		students.setStuemail(this.getStuEmail());

		int result = stuInfoService.insertSelective(students);
		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("addLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String updateStuInfo() {
		Students students = new Students();
		students.setStuid(Integer.parseInt(this.getStuId()));
		students.setStuname(this.getStuName());
		students.setClaid(Integer.parseInt(this.getClaId()));
		students.setStusex(this.getStuSex());
		students.setStuage(Integer.parseInt(this.getStuAge()));
		students.setStutel(this.getStuTel());
		students.setStuemail(this.getStuEmail());

		int result = stuInfoService.updateByPrimaryKeySelective(students);

		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("updateLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);

		return SUCCESS;
	}

	public String delStuInfo() {

		int result = stuInfoService.deleteByPrimaryKey(Integer.parseInt(this
				.getStuId()));

		Map<String, Object> jsonMap = new HashMap<String, Object>();

		jsonMap.put("deleteLine", result);
		jsonObject = JSONObject.fromObject(jsonMap);
		return SUCCESS;
	}

	public StuInfoService getStuInfoService() {
		return stuInfoService;
	}

	public void setStuInfoService(StuInfoService stuInfoService) {
		this.stuInfoService = stuInfoService;
	}

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	public String getRows() {
		return rows;
	}

	public void setRows(String rows) {
		this.rows = rows;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getStuId() {
		return stuId;
	}

	public void setStuId(String stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuSex() {
		return stuSex;
	}

	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}

	public String getStuAge() {
		return stuAge;
	}

	public void setStuAge(String stuAge) {
		this.stuAge = stuAge;
	}

	public String getStuTel() {
		return stuTel;
	}

	public void setStuTel(String stuTel) {
		this.stuTel = stuTel;
	}

	public String getStuEmail() {
		return stuEmail;
	}

	public void setStuEmail(String stuEmail) {
		this.stuEmail = stuEmail;
	}

	public String getClaId() {
		return claId;
	}

	public void setClaId(String claId) {
		this.claId = claId;
	}

}
