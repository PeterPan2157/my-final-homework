package com.ali.action;

import java.util.List;

import com.ali.model.Students;
import com.ali.resultMap.StuHomeworkResultMap;
import com.ali.service.HomeworkService;
import com.ali.service.LoginService;
import com.ali.service.TccInfoService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * 
 * @author PeterPan
 * 
 */
public class LoginAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private LoginService loginService;
	private HomeworkService homeworkService;
	private TccInfoService tccInfoService;
	private String userId;
	private String userPwd;

	public String front() {
		Students students = loginService.frontLogin(userId, userPwd);
		if (students != null) {
			homeworkService.updateHomework(students);

			// tccInfoService.selectCouByClaId(students);
			List<StuHomeworkResultMap> list = homeworkService
					.selectAllHomeworkByStuId(students.getStuid());
			ActionContext.getContext().put("homework", list);
			ActionContext.getContext().put("user", students);
			return "front-success";
		} else {
			ActionContext.getContext().put("msg", "账号或密码错误，请核对");
			return "front-error";
		}
	}

	public String backend() {
		return "backend-success";
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public LoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}

	public HomeworkService getHomeworkService() {
		return homeworkService;
	}

	public void setHomeworkService(HomeworkService homeworkService) {
		this.homeworkService = homeworkService;
	}

	public TccInfoService getTccInfoService() {
		return tccInfoService;
	}

	public void setTccInfoService(TccInfoService tccInfoService) {
		this.tccInfoService = tccInfoService;
	}

}
