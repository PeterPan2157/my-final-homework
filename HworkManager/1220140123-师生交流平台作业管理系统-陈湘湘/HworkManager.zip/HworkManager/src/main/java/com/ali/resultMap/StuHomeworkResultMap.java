package com.ali.resultMap;

public class StuHomeworkResultMap {

	private int hwpid;
	private int stuid;
	private int couid;
	private int claid;
	private int hwid;
	private String hwname;
	private String couname;
	private String hwcreatetime;
	private String hwinfo;
	private String hwpath;
	private String hwstatus;

	public String getCouname() {
		return couname;
	}

	public void setCouname(String couname) {
		this.couname = couname;
	}

	public int getHwpid() {
		return hwpid;
	}

	public void setHwpid(int hwpid) {
		this.hwpid = hwpid;
	}

	public int getStuid() {
		return stuid;
	}

	public void setStuid(int stuid) {
		this.stuid = stuid;
	}

	public int getCouid() {
		return couid;
	}

	public void setCouid(int couid) {
		this.couid = couid;
	}

	public int getClaid() {
		return claid;
	}

	public void setClaid(int claid) {
		this.claid = claid;
	}

	public int getHwid() {
		return hwid;
	}

	public void setHwid(int hwid) {
		this.hwid = hwid;
	}

	public String getHwname() {
		return hwname;
	}

	public void setHwname(String hwname) {
		this.hwname = hwname;
	}

	public String getHwcreatetime() {
		return hwcreatetime;
	}

	public void setHwcreatetime(String hwcreatetime) {
		this.hwcreatetime = hwcreatetime;
	}

	public String getHwinfo() {
		return hwinfo;
	}

	public void setHwinfo(String hwinfo) {
		this.hwinfo = hwinfo;
	}

	public String getHwpath() {
		return hwpath;
	}

	public void setHwpath(String hwpath) {
		this.hwpath = hwpath;
	}

	public String getHwstatus() {
		return hwstatus;
	}

	public void setHwstatus(String hwstatus) {
		this.hwstatus = hwstatus;
	}

	@Override
	public String toString() {
		return "StuHomeworkResultMap [hwpid=" + hwpid + ", stuid=" + stuid
				+ ", couid=" + couid + ", claid=" + claid + ", hwid=" + hwid
				+ ", hwname=" + hwname + ", couname=" + couname
				+ ", hwcreatetime=" + hwcreatetime + ", hwinfo=" + hwinfo
				+ ", hwpath=" + hwpath + ", hwstatus=" + hwstatus + "]";
	}

}
