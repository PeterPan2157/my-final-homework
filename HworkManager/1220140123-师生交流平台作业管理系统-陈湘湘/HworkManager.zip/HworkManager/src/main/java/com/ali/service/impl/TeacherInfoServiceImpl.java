package com.ali.service.impl;

import java.util.List;

import com.ali.mapper.TeacherMapper;
import com.ali.model.Teacher;
import com.ali.service.TeacherInfoService;

public class TeacherInfoServiceImpl implements TeacherInfoService {

	private TeacherMapper teacherMapper;

	public TeacherMapper getTeacherMapper() {
		return teacherMapper;
	}

	public void setTeacherMapper(TeacherMapper teacherMapper) {
		this.teacherMapper = teacherMapper;
	}

	public int deleteByPrimaryKey(Integer teachid) {
		return teacherMapper.deleteByPrimaryKey(teachid);
	}

	public int insert(Teacher record) {
		return teacherMapper.insert(record);
	}

	public int insertSelective(Teacher record) {
		return teacherMapper.insertSelective(record);
	}

	public Teacher selectByPrimaryKey(Integer teachid) {
		return teacherMapper.selectByPrimaryKey(teachid);
	}

	public int updateByPrimaryKeySelective(Teacher record) {
		return teacherMapper.updateByPrimaryKeySelective(record);
	}

	public int updateByPrimaryKey(Teacher record) {
		return teacherMapper.updateByPrimaryKey(record);
	}

	public List<Teacher> selectAllTeachInfo(Integer startNo, Integer pageSize) {
		return teacherMapper.selectAllTeachInfo(startNo, pageSize);
	}

	public int countTeachInfo() {
		return teacherMapper.countTeachInfo();
		
	}

}
