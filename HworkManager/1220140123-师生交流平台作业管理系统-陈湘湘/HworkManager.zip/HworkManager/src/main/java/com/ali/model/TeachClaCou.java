package com.ali.model;

public class TeachClaCou {
	private Integer tccid;

	private Integer teachid;

	private Integer claid;

	private Integer couid;

	private String tccstatus;

	public Integer getTccid() {
		return tccid;
	}

	public void setTccid(Integer tccid) {
		this.tccid = tccid;
	}

	public Integer getTeachid() {
		return teachid;
	}

	public void setTeachid(Integer teachid) {
		this.teachid = teachid;
	}

	public Integer getClaid() {
		return claid;
	}

	public void setClaid(Integer claid) {
		this.claid = claid;
	}

	public Integer getCouid() {
		return couid;
	}

	public void setCouid(Integer couid) {
		this.couid = couid;
	}

	public String getTccstatus() {
		return tccstatus;
	}

	public void setTccstatus(String tccstatus) {
		this.tccstatus = tccstatus;
	}

	@Override
	public String toString() {
		return "TeachClaCou [tccid=" + tccid + ", teachid=" + teachid
				+ ", claid=" + claid + ", couid=" + couid + ", tccstatus="
				+ tccstatus + "]";
	}

}