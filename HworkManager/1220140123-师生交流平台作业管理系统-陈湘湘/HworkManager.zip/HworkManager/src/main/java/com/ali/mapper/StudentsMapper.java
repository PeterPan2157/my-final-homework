package com.ali.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ali.model.Students;
import com.ali.resultMap.StuResultMap;

public interface StudentsMapper {


	int deleteByPrimaryKey(Integer stuid);

	int insert(Students record);

	int insertSelective(Students record);

	Students selectByPrimaryKey(Integer stuid);

	int updateByPrimaryKeySelective(Students record);

	int updateByPrimaryKey(Students record);

	// TODO：开始写自己的方�?
	List<StuResultMap> selectAllStuInfo(@Param("startNo") Integer startNo,
			@Param("pageSize") Integer pageSize);

	int countStuInfo();
}