package com.ali.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ali.model.Homework;
import com.ali.resultMap.StuHomeworkResultMap;

public interface HomeworkMapper {
	int deleteByPrimaryKey(Integer hwid);

	int insert(Homework record);

	int insertSelective(Homework record);

	Homework selectByPrimaryKey(Integer hwid);

	int updateByPrimaryKeySelective(Homework record);

	int updateByPrimaryKey(Homework record);

	// TODO
	/**
	 * 查询学生作业表中所有的作业
	 * 
	 * @param stuId
	 * @return
	 */
	public List<Homework> selectStuHomeworkByStuId(@Param("stuId") Integer stuId);

	/**
	 * 查询学生某一课程下的所有作业
	 * 
	 * @param stuId
	 * @param couId
	 * @return
	 */
	public List<Homework> selectStuHomeworkByCouId(
			@Param("stuId") Integer stuId, @Param("couId") Integer couId);

	/**
	 * 统计学生作业表数目
	 * 
	 * @return
	 */
	public int countHomeworkByStuId(@Param("stuId") Integer stuId);

	/**
	 * 查询某个学生名下所有的作业
	 * 
	 * @param stuId
	 * @return
	 */
	public List<StuHomeworkResultMap> selectAllHomeworkByStuId(
			@Param("stuId") Integer stuId);
	
	public int updateHwPath(Homework record);
}