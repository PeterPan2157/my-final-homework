package com.ali.service;

import java.util.List;

import com.ali.model.Students;
import com.ali.resultMap.StuResultMap;

public interface StuInfoService {
	int deleteByPrimaryKey(Integer stuid);

	int insert(Students record);

	int insertSelective(Students record);

	Students selectByPrimaryKey(Integer stuid);

	int updateByPrimaryKeySelective(Students record);

	int updateByPrimaryKey(Students record);

	// TODO：开始写自己的方法
	List<StuResultMap> selectAllStuInfo(Integer startNo, Integer pageSize);

	int countStuInfo();
}