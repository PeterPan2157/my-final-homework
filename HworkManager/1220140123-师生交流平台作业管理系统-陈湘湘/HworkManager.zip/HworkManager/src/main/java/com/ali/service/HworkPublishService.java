package com.ali.service;

import java.util.List;

import com.ali.model.HworkPublish;
import com.ali.resultMap.HworkPublishResultMap;

public interface HworkPublishService {
	int deleteByPrimaryKey(Integer hwpid);

	int insert(HworkPublish record);

	int insertSelective(HworkPublish record);

	HworkPublish selectByPrimaryKey(Integer hwpid);

	int updateByPrimaryKeySelective(HworkPublish record);

	int updateByPrimaryKey(HworkPublish record);

	public List<HworkPublish> selectHworkPublishByClaId(Integer claId);

	public List<HworkPublish> selectHworkPublishByCouId(Integer claId,
			Integer couId);

	public int countHworkPublishByClaId(Integer claId);

	// TODO
	public List<HworkPublishResultMap> selectAllHwpRM(Integer startNo,
			Integer pageSize);

	public int countHworkPublishInfo();
}
