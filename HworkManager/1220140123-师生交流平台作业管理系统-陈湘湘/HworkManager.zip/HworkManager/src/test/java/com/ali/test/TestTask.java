package com.ali.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ali.model.Homework;
import com.ali.model.Students;
import com.ali.resultMap.StuHomeworkResultMap;
import com.ali.service.HomeworkService;
import com.ali.service.LoginService;

public class TestTask {
	@Test
	public void HelloTest() throws Exception {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"applicationContext-mybatis.xml",
				"applicationContext-service.xml");

		HomeworkService homeworkService = (HomeworkService) applicationContext
				.getBean("homeworkService");
		Students students = new Students();
		students.setStuid(19);
		students.setClaid(8);
		homeworkService.updateHomework(students);
		// TeachClaCou teachClaCou = tccService.selectTccByPrimaryKey(1);
		// List<TeachClaCou> teachClaCou = tccService.selectTccByClaId(1);
		// TccResultMap tccResultMap=tccService.selectTccRMByPrimaryKey(1);
		// List<TccResultMap> tccResultMap=tccService.selectTccRMByTeachId(1);
		// System.out.println(tccResultMap.toString());

	}
}
